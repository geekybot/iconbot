# Telegram Bot with ICX



[![Build Status](https://travis-ci.org/joemccann/dillinger.svg?branch=master)](https://travis-ci.org/joemccann/dillinger)

Pluttest Bot is a Telegram bot, that works with ICON blockchain network.

  - It currently running on Icon testnet "Yeouido"
  - The bot is designed to tip, withdraw icx and other irc2 tokens   
# Commands!

  - **/help:** List of commands available
  - **/commands:**  /tip command format.
  - **/start:** Creates a wallet for the new user, or greets a returning user
  - **/hi:** Greetings
  - **/balance:** Displays ICX and IRC2 balance
 
### Tech
- MongoDB
- python-telegram-bot
- iconsdk
- pymongo